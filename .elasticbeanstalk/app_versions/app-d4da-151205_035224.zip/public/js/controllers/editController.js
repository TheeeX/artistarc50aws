myApp.controller('aboutController', ['$scope', function($scope){

}]);