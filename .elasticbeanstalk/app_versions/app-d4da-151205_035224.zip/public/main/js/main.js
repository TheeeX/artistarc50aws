
            $(document).ready(function() {
 	            if ($(document).scrollTop() > 30) {
	               $('.navbar-top').addClass('artist-header_shrink');
	            }
            });

            /*----------------- [ stream ] --------------------*/

            /*$('.navbar-top').click(function(event) {
	            $('#stream').toggleClass('active');
	            });
            */


            $('#stream-call').click(function (event) {
	              //alert('now');
	              $('#stream').toggleClass('active');
	        });

           /*-------------- form submit functions --------------*/
            
           
           /*------------------/ . ---------------------------*/

           