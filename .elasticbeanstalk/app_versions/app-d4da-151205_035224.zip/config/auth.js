module.exports = {
	'facebookAuth' : {
		'clientID': '779525218836331',
		'clientSecret': '22ea07cd7644eb3e6eac1ffd15ddbde8',
		'callbackURL': 'http://artistarc50.elasticbeanstalk.com/auth/facebook/callback'
	},

	'googleAuth' : {
		'clientID': '741095915457-r00nc2kks19gpd169ovt34n3o2nol192.apps.googleusercontent.com',
		'clientSecret': 'iJRotqAvBFzXZBDwpgqYM4-Y',
		'callbackURL': 'http://artistarc50.elasticbeanstalk.com/auth/google/callback'
	}
}