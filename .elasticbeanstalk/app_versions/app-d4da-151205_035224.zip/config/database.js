module.exports = {
	'url'	: 'mongodb://karanjeet96:wazxdws123@ds052408.mongolab.com:52408/artistarc_alpha'
}